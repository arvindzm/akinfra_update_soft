<?php
require_once '../includes/config.php';

// Allow from any origin for webhooks
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['message' => 'Method not allowed.']);
    exit;
}

$data = json_decode(file_get_contents("php://input"));

if (!isset($data->name) || !isset($data->phone)) {
    http_response_code(400);
    echo json_encode(['message' => 'Incomplete data. Name and Phone are required.']);
    exit;
}

$source = isset($data->source) ? trim($data->source) : 'API';
$name = trim($data->name);
$email = isset($data->email) ? trim($data->email) : null;
$phone = trim($data->phone);

try {
    // Implement Round-Robin Assignment for Telecallers
    // Find all active telecallers
    $stmt = $pdo->query("SELECT id FROM users WHERE role = 'telecaller'");
    $telecallers = $stmt->fetchAll(PDO::FETCH_COLUMN);

    if (count($telecallers) == 0) {
        $assigned_telecaller = null; // No telecallers available
    } else {
        // Find the telecaller who received a lead the longest time ago
        $placeholders = str_repeat('?,', count($telecallers) - 1) . '?';
        $query = "
            SELECT u.id, MAX(l.created_at) as last_assigned 
            FROM users u
            LEFT JOIN leads l ON u.id = l.telecaller_id
            WHERE u.id IN ($placeholders)
            GROUP BY u.id
            ORDER BY last_assigned ASC
            LIMIT 1
        ";
        $stmt = $pdo->prepare($query);
        $stmt->execute($telecallers);
        $result = $stmt->fetch();
        
        $assigned_telecaller = $result ? $result['id'] : $telecallers[0];
    }

    // Insert the new lead
    $insert_query = "INSERT INTO leads (source, name, email, phone, status, telecaller_id) VALUES (?, ?, ?, ?, 'New', ?)";
    $stmt = $pdo->prepare($insert_query);
    $stmt->execute([$source, $name, $email, $phone, $assigned_telecaller]);

    http_response_code(201);
    echo json_encode([
        'message' => 'Lead successfully added and assigned.',
        'telecaller_id' => $assigned_telecaller
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['message' => 'Database error.', 'error' => $e->getMessage()]);
}
?>
