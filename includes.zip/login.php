<?php
require_once 'includes/config.php';

if (isLoggedIn()) {
    redirect('index.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $login_role = $_POST['login_role'];

    if (empty($email) || empty($password)) {
        $error = 'Please enter both email and password.';
    } else {
        $stmt = $pdo->prepare('SELECT id, name, email, password, role FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            
            // STRICT ROLE VALIDATION
            if ($user['role'] !== $login_role) {
                $error = "Access Denied: You selected '$login_role' but this email belongs to a '{$user['role']}'. Please select the correct role.";
            } else {
                // Password is correct & Role matches
                $_SESSION['user_id'] = $user['id'];
                unset($user['password']); // don't store password in session
                $_SESSION['user'] = $user;
                
                redirect('index.php');
            }
        } else {
            $error = 'Invalid email or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | CRM Leads</title>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>📈</text></svg>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-white">
    <div class="row g-0 vh-100">
        <!-- Left Image Side -->
        <div class="col-lg-6 d-none d-lg-flex align-items-center justify-content-center position-relative" style="background: url('https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop') center/cover no-repeat;">
            <!-- Gradient Overlay -->
            <div style="position: absolute; inset: 0; background: linear-gradient(135deg, rgba(79, 70, 229, 0.85) 0%, rgba(14, 165, 233, 0.85) 100%);"></div>
            
            <div class="text-white text-center position-relative px-5" style="z-index: 1;">
                <i class="fa-solid fa-chart-line mb-4" style="font-size: 4.5rem; text-shadow: 0 4px 15px rgba(0,0,0,0.2);"></i>
                <h1 class="fw-bolder mb-3 display-4" style="letter-spacing: -1px;">CRM Leads Pro</h1>
                <p class="lead fw-normal text-white-50 mx-auto" style="max-width: 400px; font-size: 1.15rem;">Streamline your sales pipeline, track every lead, and boost your team's conversion rates.</p>
            </div>
        </div>

        <!-- Right Form Side -->
        <div class="col-lg-6 d-flex align-items-center justify-content-center" style="background-color: #ffffff;">
            <div class="w-100" style="max-width: 420px; padding: 2rem;">
                <div class="text-center mb-5">
                    <div class="d-lg-none mb-4">
                        <i class="fa-solid fa-chart-line text-primary" style="font-size: 3rem;"></i>
                    </div>
                    <h2 class="fw-bolder text-dark mb-2" style="font-size: 2rem; letter-spacing: -0.5px;">Welcome Back</h2>
                    <p class="text-muted">Sign in to your account to continue</p>
                </div>

                <?php if(!empty($error)): ?>
                    <div class="alert alert-danger shadow-sm border-0" style="border-radius: 12px; font-weight: 500;">
                        <i class="fa-solid fa-circle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="mb-4">
                        <label for="login_role" class="form-label text-dark fw-bold small text-uppercase" style="letter-spacing: 0.5px;">Login As</label>
                        <select class="form-select form-select-lg bg-light border-0 shadow-none" id="login_role" name="login_role" required style="border-radius: 12px; font-size: 1rem;">
                            <option value="admin">Admin</option>
                            <option value="telecaller">Telecaller</option>
                            <option value="sales">Salesperson</option>
                        </select>
                    </div>
                    <div class="mb-4">
                        <label for="email" class="form-label text-dark fw-bold small text-uppercase" style="letter-spacing: 0.5px;">Email Address</label>
                        <input type="email" class="form-control form-control-lg bg-light border-0 shadow-none" id="email" name="email" required placeholder="name@company.com" style="border-radius: 12px; font-size: 1rem;">
                    </div>
                    <div class="mb-5">
                        <label for="password" class="form-label text-dark fw-bold small text-uppercase" style="letter-spacing: 0.5px;">Password</label>
                        <div class="password-wrapper position-relative">
                            <input type="password" class="form-control form-control-lg bg-light border-0 shadow-none" id="password" name="password" required placeholder="••••••••" style="border-radius: 12px; font-size: 1rem;">
                            <i class="fa-regular fa-eye toggle-password position-absolute" onclick="togglePassword('password', this)" style="right: 15px; top: 50%; transform: translateY(-50%); cursor: pointer; color: #6b7280;"></i>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 py-3 fw-bold shadow-sm" style="border-radius: 12px; font-size: 1.1rem; background: linear-gradient(135deg, #4f46e5 0%, #3b82f6 100%); border: none;">Log In to Dashboard</button>
                </form>
                
                <div class="text-center mt-4">
                    <p class="text-muted small">Need an account? Contact your Admin</p>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePassword(inputId, iconElement) {
            const input = document.getElementById(inputId);
            if (input.type === "password") {
                input.type = "text";
                iconElement.classList.remove("fa-eye");
                iconElement.classList.add("fa-eye-slash");
            } else {
                input.type = "password";
                iconElement.classList.remove("fa-eye-slash");
                iconElement.classList.add("fa-eye");
            }
        }
    </script>
</body>
</html>
