<?php
if (!defined('PDO::ATTR_ERRMODE')) require_once 'config.php';

// Handle manual lead addition
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add_lead_manual') {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    
    // Auto assign to least recently assigned telecaller
    $stmt = $pdo->query("SELECT id FROM users WHERE role = 'telecaller'");
    $telecallers = $stmt->fetchAll(PDO::FETCH_COLUMN);
    $assigned_telecaller = null;
    if (count($telecallers) > 0) {
        $placeholders = str_repeat('?,', count($telecallers) - 1) . '?';
        $stmt = $pdo->prepare("SELECT u.id, MAX(l.created_at) as last_assigned FROM users u LEFT JOIN leads l ON u.id = l.telecaller_id WHERE u.id IN ($placeholders) GROUP BY u.id ORDER BY last_assigned ASC LIMIT 1");
        $stmt->execute($telecallers);
        $result = $stmt->fetch();
        $assigned_telecaller = $result ? $result['id'] : $telecallers[0];
    }

    $insert_stmt = $pdo->prepare("INSERT INTO leads (source, name, email, phone, status, telecaller_id) VALUES ('manual', ?, ?, ?, 'New', ?)");
    $insert_stmt->execute([$name, $email, $phone, $assigned_telecaller]);
    $success = "Lead added manually and assigned to a telecaller.";
}

// Fetch basic stats
$total_leads = $pdo->query("SELECT COUNT(*) FROM leads")->fetchColumn();
$new_leads = $pdo->query("SELECT COUNT(*) FROM leads WHERE status='New'")->fetchColumn();
$converted = $pdo->query("SELECT COUNT(*) FROM leads WHERE status='Converted'")->fetchColumn();
$total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();

// Fetch recent leads
$stmt = $pdo->query("
    SELECT l.*, t.name as telecaller_name, s.name as sales_name 
    FROM leads l
    LEFT JOIN users t ON l.telecaller_id = t.id
    LEFT JOIN users s ON l.salesperson_id = s.id
    ORDER BY l.created_at DESC LIMIT 10
");
$recent_leads = $stmt->fetchAll();

// Fetch Graph Data
// 1. Leads by Status
$status_data = $pdo->query("SELECT status, COUNT(*) as count FROM leads GROUP BY status")->fetchAll();
$all_statuses = ['New', 'In Progress', 'Assigned to Sales', 'Converted', 'Dead'];
$status_counts_map = array_fill_keys($all_statuses, 0);

foreach($status_data as $row) {
    $status_counts_map[$row['status']] = $row['count'];
}
$status_labels = array_keys($status_counts_map);
$status_counts = array_values($status_counts_map);

// Fallback for empty doughnut chart
$chart_bg_colors = ['#4f46e5', '#0ea5e9', '#10b981', '#f59e0b', '#ef4444'];
if(array_sum($status_counts) == 0) {
    $status_labels = ['No Data Yet'];
    $status_counts = [1];
    $chart_bg_colors = ['#e2e8f0']; // Grey
}


// 2. Leads Last 7 Days
$trend_labels = [];
$trend_counts_map = [];
for($i = 6; $i >= 0; $i--) {
    $date_str = date('Y-m-d', strtotime("-$i days"));
    $trend_labels[] = date('M d', strtotime($date_str));
    $trend_counts_map[$date_str] = 0;
}

$trend_data = $pdo->query("SELECT DATE(created_at) as date, COUNT(*) as count FROM leads WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) GROUP BY DATE(created_at) ORDER BY date")->fetchAll();
foreach($trend_data as $row) {
    if(isset($trend_counts_map[$row['date']])) {
        $trend_counts_map[$row['date']] = $row['count'];
    }
}
$trend_counts = array_values($trend_counts_map);
?>

<div class="row mb-4 g-4">
    <div class="col-md-3">
        <div class="metric-card bg-gradient-primary">
            <div class="metric-info">
                <h6>Total Leads</h6>
                <h2><?php echo $total_leads; ?></h2>
            </div>
            <div class="metric-icon">
                <i class="fa-solid fa-database"></i>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card bg-gradient-info">
            <div class="metric-info">
                <h6>New Leads</h6>
                <h2><?php echo $new_leads; ?></h2>
            </div>
            <div class="metric-icon">
                <i class="fa-solid fa-bell"></i>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card bg-gradient-success">
            <div class="metric-info">
                <h6>Converted</h6>
                <h2><?php echo $converted; ?></h2>
            </div>
            <div class="metric-icon">
                <i class="fa-solid fa-check-circle"></i>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card bg-gradient-warning">
            <div class="metric-info">
                <h6>Team Members</h6>
                <h2><?php echo $total_users; ?></h2>
            </div>
            <div class="metric-icon">
                <i class="fa-solid fa-users"></i>
            </div>
        </div>
    </div>
</div>

<div class="row mb-4 g-4">
    <div class="col-md-8">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title mb-4">Leads Trend (Last 7 Days)</h5>
                <div style="position: relative; height: 250px; width: 100%;">
                    <canvas id="leadsTrendChart"></canvas>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title mb-4">Leads by Status</h5>
                <div style="position: relative; height: 250px; width: 100%;">
                    <canvas id="leadsStatusChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="table-card">
    <div class="table-header d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center gap-3">
        <h5 class="mb-0">Recent Leads Overview</h5>
        <div class="d-flex gap-2 flex-wrap">
            <button class="btn btn-sm btn-primary text-nowrap" data-bs-toggle="modal" data-bs-target="#addLeadModal">
                <i class="fa-solid fa-plus me-1"></i> Add Lead
            </button>
            <a href="leads.php" class="btn btn-sm btn-outline-primary text-nowrap">View All</a>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Lead Name</th>
                    <th>Source</th>
                    <th>Telecaller</th>
                    <th>Salesperson</th>
                    <th>Status</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($recent_leads as $lead): ?>
                <tr>
                    <td>
                        <div class="fw-semibold"><?php echo htmlspecialchars($lead['name']); ?></div>
                        <div class="text-muted small"><?php echo htmlspecialchars($lead['phone']); ?></div>
                    </td>
                    <td><span class="text-capitalize text-muted"><i class="fa-brands fa-<?php echo strtolower($lead['source']); ?> me-1"></i> <?php echo htmlspecialchars($lead['source']); ?></span></td>
                    <td><?php echo htmlspecialchars($lead['telecaller_name'] ?? 'Unassigned'); ?></td>
                    <td><?php echo htmlspecialchars($lead['sales_name'] ?? 'Unassigned'); ?></td>
                    <td>
                        <?php 
                            $badge_class = 'bg-secondary';
                            switch($lead['status']) {
                                case 'New': $badge_class = 'badge-new'; break;
                                case 'In Progress': $badge_class = 'badge-progress'; break;
                                case 'Assigned to Sales': $badge_class = 'badge-assigned'; break;
                                case 'Converted': $badge_class = 'badge-converted'; break;
                                case 'Dead': $badge_class = 'badge-dead'; break;
                            }
                        ?>
                        <span class="badge <?php echo $badge_class; ?>"><?php echo $lead['status']; ?></span>
                    </td>
                    <td class="text-muted small"><?php echo date('M d, Y', strtotime($lead['created_at'])); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if(count($recent_leads) == 0): ?>
                <tr><td colspan="6" class="text-center py-4 text-muted">No leads found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Lead Modal -->
<div class="modal fade" id="addLeadModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Lead</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="action" value="add_lead_manual">
                    
                    <div class="mb-3">
                        <label class="form-label text-muted fw-semibold">Lead Name</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted fw-semibold">Phone Number</label>
                        <input type="text" name="phone" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted fw-semibold">Email (Optional)</label>
                        <input type="email" name="email" class="form-control">
                    </div>
                    <div class="alert alert-info py-2 small mb-0">
                        <i class="fa-solid fa-circle-info me-1"></i> This lead will be automatically assigned to the next available telecaller.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Lead</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Lead Trend Chart
    const trendCtx = document.getElementById('leadsTrendChart').getContext('2d');
    new Chart(trendCtx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($trend_labels); ?>,
            datasets: [{
                label: 'New Leads',
                data: <?php echo json_encode($trend_counts); ?>,
                borderColor: '#4f46e5',
                backgroundColor: 'rgba(79, 70, 229, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { beginAtZero: true, ticks: { precision: 0 } }
            }
        }
    });

    // Lead Status Doughnut Chart
    const statusCtx = document.getElementById('leadsStatusChart').getContext('2d');
    new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode($status_labels); ?>,
            datasets: [{
                data: <?php echo json_encode($status_counts); ?>,
                backgroundColor: <?php echo json_encode($chart_bg_colors); ?>,
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            cutout: '75%',
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });
});
</script>
